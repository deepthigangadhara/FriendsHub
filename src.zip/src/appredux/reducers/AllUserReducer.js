import * as actionType from '../actions/ActionTypes'

export default function AllUserReducer(state=[],action)
{
    switch(action.type){
        case actionType.ALL_USERS: return {
            ...state,allusers:action.payload.allusers
        }
        
        default: return state                                
    }
}