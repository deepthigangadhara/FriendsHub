import * as actionType from '../actions/ActionTypes'

export default function FriendRequestReducer(state=[],action){
    switch(action.type)
    {
        case actionType.FRIEND_REQUEST: return {
            ...state,friendRequest:action.payload.friendRequest
        }
        default: return state      
    }
}