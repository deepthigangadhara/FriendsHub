import { combineReducers ,createStore} from 'redux'

import UserReducer from './reducers/UserReducer'

var store = createStore(combineReducers({
    user : UserReducer
}),{
   
    user : { loginstatus : false, token : undefined , username : undefined}
})

export default store