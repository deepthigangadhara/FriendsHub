import { combineReducers ,createStore} from 'redux'
import AllUserReducer from './reducers/AllUserReducer'
import FriendReducer from './reducers/FriendReducer'
import FriendRequestReducer from './reducers/FriendRequestReducer'

import UserReducer from './reducers/UserReducer'

var store = createStore(combineReducers({
    user : UserReducer,
    allusersdata:AllUserReducer,
    friendrequest: FriendRequestReducer,
    allfriendsdata:FriendReducer
}),{
   
    user : { loginstatus : false, token : undefined , userID : undefined, userName : undefined, email : undefined, userImage: undefined},
    allusersdata:{ allusers:[]},
    friendrequest:{friendRequest:[]},
    allfriendsdata:{allFriends:[]}
})
//var store = createStore(UserReducer)

export default store