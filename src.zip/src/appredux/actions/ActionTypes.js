export const USER_LOGIN = "userLogin"
export const USER_LOGOUT = "userLogout"
export const USER_UPDATE_TOKEN = "updateToken"

export const ALL_USERS="allUsers"

export const FRIEND_REQUEST="friendRequest"

export const ALL_FRIENDS="allFriends"