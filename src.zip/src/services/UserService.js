import packageJson from '../../package.json';
import axios from "axios"
class UserService{
    registerUser = (data)=>{
        return fetch(`${packageJson.server}/user/register`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
   loginUser = (data)=>{
        return fetch(`${packageJson.server}/user/login`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
    verifyUser = (data)=>{
        return fetch(`${packageJson.server}/user/verify`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
    getUser = (token)=>{
        return fetch(`${packageJson.server}/user/getUser`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization" : 'Bearer '.concat(token)
            }
        })
    }

    updateProfile = (data,token)=>{
        return fetch(`${packageJson.server}/user/updateProfile/{id}`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization" : 'Bearer '.concat(token)
            },
            body: JSON.stringify(data)
        })
    }

}
var obj = new UserService()
export default obj;