import React from 'react'
import './otp.css';
import {Link} from 'react-router-dom'
class Verified extends React.Component{
    render(){
        return<div>
              <div className="outer">
        <div className="inner">
            <div className="container text-center">
                <h4><b>Congratulations, your account has been verified.</b></h4>
                <br></br>
                <h4><Link to="/">Click here to Login</Link></h4>
            </div>
        </div></div></div>
    }
}
export default Verified