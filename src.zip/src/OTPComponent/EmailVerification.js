import React from 'react'
import './otp.css';
import userService from '../services/UserService'
import {Navigate} from 'react-router-dom'
import { colors } from '@material-ui/core';
class EmailVerification extends React.Component {
    constructor() {
        super()
        this.state = {
            verifystatus: false,
            verifymsg: ''
        }
    }

    verify = (event) => {
        var ob = {

            oneTimePassword: this.otpbox.value,
        }
        userService.verifyUser(ob).then(response => response.json()).then(data => {
            console.log(data)
            this.setState({ verifymsg: data.msg })
            if (data.status)
                this.setState({ verifystatus: true })
        });;


        event.preventDefault()
    }
   
    render() {
        if (this.state.verifystatus) {
            return <Navigate to="/verified" />
        }
        
        return <div>
              <div className="outer">
        <div className="inner">
            <form onSubmit={this.verify}>
            <div className="container text-center">
                <h4 ><b>You have signed up successfully!</b></h4>
                <p>Please check your email to get OTP.</p>
                </div>

                <div className="form-group">
                    <label>OTP</label>
                    <input ref={c => this.otpbox = c} type="text" className="form-control" placeholder="Enter OTP" required />
                </div>
                <br></br>
                <div >
                    &nbsp;
                    <b className='text-danger'>{this.state.verifymsg}</b>

                </div>
                <br></br>
                <button type="submit" className="btn btn-dark btn-lg btn-block">Verify</button>

            </form></div></div>
        </div>
    }
}
export default EmailVerification