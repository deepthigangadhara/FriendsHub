package com.example.friendshub.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class JWTResponseData {
    
	private boolean status;
	private String token;
	private String msg;
	private String userID;
	private String userName;
	private String email;
	private String userImage;
	//private Date joiningDate;

	
}
