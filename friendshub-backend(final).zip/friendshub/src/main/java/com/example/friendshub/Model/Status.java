package com.example.friendshub.Model;

import java.sql.Timestamp;
import java.util.Date;
//import java.security.Timestamp;
import java.util.UUID;

import org.springframework.data.annotation.Id;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Status {

	@Id
	private UUID statusID;
	
	private String userID;
	private String userName;
	private String userImage;
	private String statusImageURL;
	private Date uploadTime;
	
	public Status() {
		super();
	}

	public Status(UUID statusID, String userID, String statusImageURL,String userName, String userImage,Timestamp uploadTIme) {
		super();
		this.statusID = statusID;
		this.userID = userID;
		this.userName = userName;
		this.userImage = userImage;
		this.statusImageURL = statusImageURL;
		this.uploadTime = uploadTIme;
	}
    
}
