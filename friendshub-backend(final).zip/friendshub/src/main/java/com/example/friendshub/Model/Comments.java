package com.example.friendshub.Model;

import java.util.Date;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Comments {
    @Id
    private String commentID;
    private String postID;
    private String userID;   //friendID
    private String userName;
    private String userImage;
    private String comment;
    private Date time;
    
}
