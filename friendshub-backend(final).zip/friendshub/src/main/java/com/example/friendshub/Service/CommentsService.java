package com.example.friendshub.Service;

import java.util.ArrayList;

import com.example.friendshub.Model.Comments;
import com.example.friendshub.Repository.CommentsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentsService {
    @Autowired
	CommentsRepository commentsRepository;
	
    public Comments saveComments(Comments comments) {
		
		return commentsRepository.save(comments);
	}

	public ArrayList<Comments> retrieveAllComments(){
		return commentsRepository.findAll();
	}
}
