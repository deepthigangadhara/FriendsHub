package com.example.friendshub.response;

//import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@AllArgsConstructor
public class ImageResponseData {
    private boolean status;
	private String imageBase64;
	private String imagePath;
    
}
