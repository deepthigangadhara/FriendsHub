package com.example.friendshub.Service;

import java.util.ArrayList;
import java.util.Date;

import com.example.friendshub.Model.FriendRequest;
import com.example.friendshub.Repository.FriendRequestRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FriendRequestService {
    @Autowired
    FriendRequestRepository friendRequestRepository;
   
    public FriendRequest saveRequest(FriendRequest request) {
		request.setStatus(false);
        Date date=new Date();
			request.setRequestDate(date);
		return friendRequestRepository.save(request);
	}
    public ArrayList<FriendRequest> retrieveAllUserDetails(){
		return friendRequestRepository.findAll();
	}
}
