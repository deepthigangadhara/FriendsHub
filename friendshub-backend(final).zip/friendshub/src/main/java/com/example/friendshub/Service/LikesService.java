package com.example.friendshub.Service;

import java.util.ArrayList;

import com.example.friendshub.Model.Likes;
import com.example.friendshub.Repository.LikesRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LikesService {
    @Autowired
	LikesRepository likesRepository;
	
    public Likes saveLikes(Likes likes) {
		
		return likesRepository.save(likes);
	}

	public ArrayList<Likes> retrieveAllLikes(){
		return likesRepository.findAll();
	}
}
