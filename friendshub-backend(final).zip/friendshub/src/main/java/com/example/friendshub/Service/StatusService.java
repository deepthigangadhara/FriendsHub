package com.example.friendshub.Service;

//import java.security.Timestamp;
//import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

//import java.sql.Date;

import com.example.friendshub.Model.Status;
import com.example.friendshub.Repository.StatusRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StatusService {
    @Autowired
	StatusRepository statusRepo;
	
	public Status saveStatus(Status status) {
		
		Date date=new Date();
		//long time=date.getTime();
		//Timestamp dateTime=new Timestamp(time);
		
		status.setStatusID(UUID.randomUUID());
		status.setUploadTime(date);
		return statusRepo.save(status);
	}
	
	public ArrayList<Status> getAllStatus(){
		ArrayList<Status> result=new ArrayList<Status>();
		result=statusRepo.findAll();
		result.sort((e1, e2) -> e2.getUploadTime().compareTo(e1.getUploadTime()));
		return result;
	}
}
