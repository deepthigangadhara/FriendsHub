package user.authentication.Service;



import java.util.Date;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import net.bytebuddy.utility.RandomString;
import user.authentication.Model.User;
import user.authentication.Repository.UserRepository;



@Service
public class UserService {
    @Autowired
	private UserRepository userRepository;
	
	
	public User saveUser(User user) 
	{
		try {
			user.setRoles("ROLE_USER");
			//user.setActive(true);
			Date date=new Date();
			user.setJoiningDate(date);
			userRepository.insert(user);		
			return user;
		}catch(Exception ex) {
			return null;
		}
	}
	public User getById(String userid) 
	{
		return userRepository.findById(userid).get();	
	}
	public User getByEmail(String email) 
	{
		return userRepository.findByEmail(email);		
	}
	
	public boolean verify(Number OTP) {
		User user = userRepository.findByOneTimePassword(OTP);
		//if(OTP==user.getOneTimePassword()) 
		//System.out.println(OTP);
		if (user == null || user.getActive()) {
			return false;
		} else  {
			user.setOneTimePassword(0);
			user.setActive(true);
			userRepository.save(user);
			 
			return true;
		}
		 
	}
}
