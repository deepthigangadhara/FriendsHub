package user.authentication.Repository;



import org.springframework.data.mongodb.repository.MongoRepository;

//import patientsapi.demo.Model.SystemUser;
import user.authentication.Model.User;

public interface UserRepository extends MongoRepository<User, String>{
	public User findByEmail(String email);
    Boolean existsByEmail(String email);
    public User findByOneTimePassword(Number oneTimePassword);
}
