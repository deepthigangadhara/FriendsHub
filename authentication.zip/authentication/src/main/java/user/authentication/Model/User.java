package user.authentication.Model;


import java.util.Date;
//import java.sql.Timestamp;
//import java.sql.Timestamp;
import java.util.Objects;

//import java.security.Timestamp;

import org.springframework.data.annotation.Id;
//import org.springframework.data.mongodb.core.mapping.Document;

//import io.jsonwebtoken.lang.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
//@Document(collection = "user")
public class User {
    @Id
	private String userID;

	private String userName;
    private String email;
    private String password;
	private String userImage;
	private Boolean active;
    private String roles;
	//private Timestamp joiningDate;
    private Date joiningDate;
	
    //private static final long OTP_VALID_DURATION = 5 * 60 * 1000;   // 5 minutes
     
   
    private Number oneTimePassword;
     
    
   // private Date otpRequestedTime;
     
    //private boolean enabled;
    /*public boolean isOTPRequired() {
        if (this.getOneTimePassword() == null) {
            return false;
        }
         
        long currentTimeInMillis = System.currentTimeMillis();
        long otpRequestedTimeInMillis = this.otpRequestedTime.getTime();
         
        if (otpRequestedTimeInMillis + OTP_VALID_DURATION < currentTimeInMillis) {
            // OTP expires
            return false;
        }
         
        return true;
    }*/
  
    
}
