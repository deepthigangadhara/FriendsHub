package user.authentication.Controller;

import java.util.Date;
import java.util.Random;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
//import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.bytebuddy.utility.RandomString;
import user.authentication.Model.User;
import user.authentication.Repository.UserRepository;
import user.authentication.Security.JwtTokenUtil;
import user.authentication.Service.UserService;
import user.authentication.response.JWTResponseData;
import user.authentication.response.ResponseData;
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public ResponseData registerUser(@RequestBody User user) {
		if (userRepository.existsByEmail(user.getEmail())) {
			return new ResponseData("User Already Exists!", null, false);
		}
		//user.setPassword(passwordEncoder.encode(user.getPassword()));
		// SendVerifyMail(user.getUserName(),user.getEmail(),121);

		User newUser = userService.saveUser(user);
		if (newUser == null)
			return new ResponseData("Not Implemented", null, false);
		else {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			generateOneTimePassword(newUser);
			return new ResponseData("Successfully Registered", newUser, true);
		}
	}

	public void generateOneTimePassword(User user) {
		Random random = new Random();
		int OTP = 100000 + random.nextInt(900000);
		// String OTP = RandomString.make(8);
		// String encodedOTP = passwordEncoder.encode(OTP);

		user.setOneTimePassword(OTP);
		//user.setOtpRequestedTime(new Date());
		user.setActive(false);
		userRepository.save(user);

		sendOTPEmail(user.getUserName(), user.getEmail(), OTP);
	}

	private boolean sendOTPEmail(String userName, String email, int OTP) {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message);

			helper.setFrom("200deepthig@gmail.com", "Friends Hub");
			helper.setTo(email);

			String subject = "Here's your One Time Password (OTP)";

			String content = "<p>Hello " + userName + "</p>"
					+ "<p>For security reason, you're required to use the following "
					+ "One Time Password to login:</p>"
					+ "<p><b>" + OTP + "</b></p>"
					+ "<br>";

			helper.setSubject(subject);

			helper.setText(content, true);

			mailSender.send(message);
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	/*public void clearOTP(User user) {
		user.setOneTimePassword(0);
		user.setOtpRequestedTime(null);
		userRepository.save(user);
	}*/

	/*
	 * private boolean SendVerifyMail(String name,String email,int otp)
	 * {
	 * try {
	 * SimpleMailMessage msg = new SimpleMailMessage();
	 * MimeMessage mimeMessage = javaMailSender.createMimeMessage();
	 * MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, false,
	 * "UTF-8");
	 * messageHelper.setFrom("200deepthig@gmail.com");
	 * messageHelper.setTo(email);
	 * messageHelper.setSubject("Verification Mail from PatientWeb");
	 * messageHelper.setText("<b>Hello</b>", true);
	 * javaMailSender.send(mimeMessage);
	 * return true;
	 * }catch(Exception ex) {
	 * System.out.println(ex.getMessage());
	 * return false;
	 * }
	 * }
	 */
	@PostMapping("/verify")
public ResponseData verifyUser(@RequestBody User user) {
	//System.out.println(user.getOneTimePassword());
    if (userService.verify(user.getOneTimePassword())) {
        return new ResponseData("verify_success",null, true);
    } else {
        return new ResponseData("Invalid OTP", null, false);
    }
}

	@PostMapping("/login")
	public ResponseEntity loginUser(@RequestBody User user) {
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));

			User newUser = userService.getByEmail(user.getEmail());
			final String token = jwtTokenUtil.generateToken(newUser);

			return ResponseEntity.ok(new JWTResponseData(true, token, "Login Successfully"));
		} catch (DisabledException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "User Disabled !"));
		} catch (BadCredentialsException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "Invalid User !"));
		}
	}

}
