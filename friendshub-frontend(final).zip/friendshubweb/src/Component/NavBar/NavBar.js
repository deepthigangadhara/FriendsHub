import React, { Component } from 'react';
import "./NavBar.css";
import Grid from '@material-ui/core/Grid'
import fblogo from "../../images/logo.png";
import home from "../../images/home.svg";
import page from "../../images/pages.svg";
import watch from "../../images/watch.svg";
import market from "../../images/market.svg";
import group from "../../images/groups.svg";
import Avatar from '@material-ui/core/Avatar';
import { Link} from 'react-router-dom';
import {connect} from 'react-redux'
import Store from '../../appredux/store'
import {ACTION_USER_LOGOUT,ACTION_USER_UPDATE_TOKEN} from '../../appredux/actions/UserAction'
import userService from '../../services/UserService'


var mapStateToProps = state => {
   return {
      user: state.user,
      allusers: state.allusersdata.allusers
   }
   
}


class NavBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
           userinfo:[]
        }
       /* var arr=this.props.allusers.filter((usr)=>usr.userID==this.props.user.userID)
        this.setState({data:arr})
        console.log(arr)
        console.log(this.state.data)*/
    }
    componentDidMount()
    {
       // this.props.data();
        //console.log(this.props.user)
        userService.getUser(this.props.user.token).then(response=>response.json()).then(data=>{
            //console.log(this.props.user.token);
            console.log(data)
            if(data.active)
            {
                //console.log(data.status)
                Store.dispatch({...ACTION_USER_UPDATE_TOKEN,payload:{
                    token : this.props.user.token
                }})
                //console.log(data.token);
                this.setState({userinfo:data})
                console.log(this.state.userinfo)
                
            }else{
                if(data.code===401)
                    alert("Invalid User !")
                if(data.code===403)
                    alert("Session Lost !")  
                Store.dispatch({...ACTION_USER_LOGOUT})                      
            }
            
        });
       
    }
   
   
    render() {
        return (
            <div>
                <Grid container className="navbar_main">
                    <Grid item xs={4}><div className='navbar_leftbar'>
                    <div className='navbar_logo'><h5><b>FriendsHub</b></h5></div>
                       &nbsp;&nbsp;&nbsp;&nbsp;
                        <input className='navbar_search' type="text" placeholder='Search FriendsHub'/>
                    </div></Grid>

                    <Grid item xs={5}> <div className="navbar_container">
                        <div className="navbar_tabs active ">
                       <Link to="/home"> <img src={home} height="35px" width="35px" className="img"/></Link>
                        </div>
                        <div className="navbar_tabs">
                        <img src={page} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={watch} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={market} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={group} height="35px" width="35px" className="img"/>
                        </div>

                    </div>
                    </Grid>

                    <Grid item xs={2}>
                        <div className="navbar_right">
                            <div className='navbar_righttab'>
                                <Link to="/profile">
                                <Avatar className="navbar_rightimg" src={this.state.userinfo.userImage} width="40" height="40"/>
                                </Link>
                               <div className='navbar_profilename'>{this.state.userinfo.userName}</div>
                                </div>
                        </div>
                    </Grid>
                </Grid>
            </div>

        );
    }
}

//export default NavBar;

export default connect(mapStateToProps)(NavBar)