import React from 'react'
import { connect } from 'react-redux'
import './FriendRequest.css'
import userService from '../services/UserService'
import Store from '../appredux/store'
import { ACTION_FRIEND_REQUEST } from '../appredux/actions/FriendRequestAction'
import * as actions from '../appredux/actions/FriendRequestAction'
import FriendRequestService from '../services/FriendRequestService'
import FriendService from '../services/FriendService'
import { getAllByLabelText } from '@testing-library/dom'
var mapStateToProps = state => {
    return {
        allusers: state.allusersdata.allusers,
        user: state.user,
        friendrequest: state.friendrequest.friendRequest
    }

}
class FriendRequest extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            request: 'Add Friend',
            userid: '',
            findfriends: [],
            frequest: "",            
            showbutton: true,
            showbuttonindex: 0, 
            friendrequest:[] ,
            requestdata:[],
            newdata:[]          
        }
        
    }
    componentDidMount() {
        userService.getUser(this.props.user.token).then(response => response.json()).then(data => {
            console.log(data)
            this.setState({ userid: data.userID })
            console.log(this.state.userid)
        }
        );
        FriendRequestService.getAllRequests()
            .then(response => response.json())
            .then(data => {
                console.log(data)
                Store.dispatch({
                    ...actions.ACTION_FRIEND_REQUEST, payload: {
                        friendRequest: data
                    }
                })
            })
        console.log(this.props.friendrequest)
    }
   componentDidUpdate(){
        this.state.findfriends=this.props.allusers.map((e)=>Object.assign({}, e, {status : 'Add Friend'}))
        console.log(this.state.findfriends)
    }
    findfriends = () => {
        var arr = []; 
        arr = this.state.findfriends.filter((usr) => usr.userID != this.state.userid) 
        console.log(arr)  
        return arr
    }
    
    delete=(event,userid)=>{
        var arr=[];
        arr = this.state.findfriends.filter((usr) => usr.userID != userid)
        console.log(arr)
        this.setState({findfriends:arr})
        this.findfriends()
        event.preventDefault();
    }
    handlechange = (event, index, userid,status) => {
        var ob = {
            userid: userid
        }
        var arr=this.state.findfriends.map((e)=>e.userID==userid?Object.assign({}, e, {status : 'Requested'}):Object.assign({}, e, {status : 'Add Friend'}))
       // console.log(arr)
        this.setState({findfriends:arr})
        //this.componentDidUpdate()
        this.findfriends()
        FriendRequestService.request(userid, this.props.user.token, ob).then(response => response.json()).then(data => {
            //console.log(data)           
        });      
        event.preventDefault();
    }

    frequest = () => {
        var arr = [];
        var user = [];
        user = this.props.friendrequest.filter((frnd) => frnd.friend_ID === this.props.user.userID)
        arr = this.props.allusers.filter((usr) => user.find(({ userID }) => usr.userID === userID))
       // console.log(arr, user)
        return arr;
    }
    deleteRequest=(event, index, userid)=>{
        console.log(userid)       
        var arr=this.props.friendrequest.filter((fr)=>fr.userID===userid&&fr.friend_ID===this.props.user.userID )
        //console.log(arr)       
        FriendRequestService.delete(arr, this.props.user.token).then(response => response.json()).then(data => {
            console.log(data)          
        });
        this.componentDidMount()
        this.frequest();
        event.preventDefault();
    }

    confirm=(event, index, friendid)=>{
        var ob={
            userid:friendid
        }
        FriendService.accept(this.props.user.userID, friendid, ob).then(response => response.json()).then(data => {
            console.log(data)         
        });
        event.preventDefault();
    }
    render() {
        return <div>
            <div className="container  d-flex justify-content-center">
                <div className="card2 p-4">
                    <div className='row'>
                        <div className='col-lg-6 '>
                            <div className="container justify-content-center"><br/>
                                <h3><b>People you may know</b></h3><br />

                                <table align="center" cellPadding="10" cellSpacing="5">
                                    <tbody>

                                        {this.findfriends().map((usr, index) => {

                                            return <tr key={index}>
                                                <td> <img  src={usr.userImage} height="70" width="70" />
                                                </td>
                                                <td><h5><b>{usr.userName}</b></h5></td>
                                                <th> <span id={index} onClick={event => this.handlechange(event, index, usr.userID,usr.status)}><button className="btn1 btn-primary btn-lg btn-block">{usr.status}</button>{/*{this.state.showbuttonindex&&index?<button>Requested</button>:<button>Add Friend</button>}*/}</span>
                                                    &nbsp;&nbsp;&nbsp;<button className="btn btn-dark btn-lg btn-block" onClick={event=>this.delete(event, usr.userID)}>Remove</button></th>
                                                <br />
                                            </tr>
                                        }
                                        )}
                                    </tbody>
                                </table>

                            </div>
                        </div>
                        <div className='col-lg-6 '>
                            <div className="container justify-content-center"><br/>
                                <h3><b>Friend Requests</b></h3><br/>
                                <table align="center" cellPadding="10" cellSpacing="5">
                                    <tbody>

                                        {this.frequest().map((usr, index) => {

                                            return <tr>
                                                <td> <img src={usr.userImage} height="70" width="70"></img>
                                                </td>
                                                <td><h5><b>{usr.userName}</b></h5></td>
                                                <td><button id={index} className="btn1 btn-primary btn-lg btn-block" onClick={event=>this.confirm(event,index, usr.userID)}>Confirm</button>&nbsp;&nbsp;&nbsp;<button className="btn btn-dark btn-lg btn-block" onClick={event => this.deleteRequest(event, index, usr.userID)}>Delete</button></td>
                                            </tr>
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    }
}
export default connect(mapStateToProps)(FriendRequest)