import * as actionType from './ActionTypes'
export const ACTION_ALL_POSTS={
    type: actionType.ALL_POSTS,
    payload:{
        allposts : undefined
    }
}