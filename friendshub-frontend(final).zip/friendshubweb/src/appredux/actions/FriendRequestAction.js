import * as actionType from './ActionTypes'
export const ACTION_FRIEND_REQUEST = {
    type : actionType.FRIEND_REQUEST ,
    payload:{
       
        friendRequest:undefined

    }
}