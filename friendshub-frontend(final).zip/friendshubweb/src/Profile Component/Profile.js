/*import React from 'react'
import "./Profile.css";
import {Navigate} from 'react-router-dom'
import userService from '../../services/UserService'
class Profile extends React.Component{
    constructor(){
        super()
        this.state={
            updateProfilemsg : '',
            updatePasswordmsg : '',
            userinfo : {name:'',phone:'',email:''}
        }
    }
/*    render(){
        return <div className='main_body'>
            <div className="container mt-4 mb-4 p-3 d-flex justify-content-center">
    <div className="card p-4">
        <div className=" image d-flex flex-column justify-content-center align-items-center"> <button className="btn1 btn-secondary"> <img src="https://i.imgur.com/wvxPV9S.png" height="100" width="100" /></button> <span className="name mt-3">Eleanor Pena</span> <span className="idd">@eleanorpena</span>
            <div className="d-flex flex-row justify-content-center align-items-center gap-2"> <span className="idd1">Oxc4c16a645_b21a</span> <span><i className="fa fa-copy"></i></span> </div>
            <div className="d-flex flex-row justify-content-center align-items-center mt-3"> <span className="number">1069 <span className="follow">Followers</span></span> </div>
            <div className=" d-flex mt-2"> <button className="btn btn-dark">Edit Profile</button> </div>
            <div className="text mt-3"> </div>
            <div className="gap-3 mt-3 icons d-flex flex-row justify-content-center align-items-center"> <span><i className="fa fa-twitter"></i></span> <span><i className="fa fa-facebook-f"></i></span> <span><i className="fa fa-instagram"></i></span> <span><i className="fa fa-linkedin"></i></span> </div>
            <div className=" px-2 rounded mt-4 date "> <span className="join">Joined May,2021</span> </div>
        </div>
    </div>
</div>
        </div>
    }
}
export default Profile */

import React from 'react'
import {Navigate, Link} from 'react-router-dom'

import userService from '../services/UserService'
import "./Profile.css";
import Store from '../appredux/store'
import {ACTION_USER_LOGOUT , ACTION_USER_UPDATE_TOKEN} from '../appredux/actions/UserAction'
import {connect} from 'react-redux'
import Friends from '../FriendComponent/Friends';
import {firebase} from "../firebase";
import Dialog from '@material-ui/core/Dialog';
import profile from '../images/profile.png'
import NavBar from '../Component/NavBar/NavBar';
var mapStateToProps = state => {
   return {
      user: state.user,
     // allusers: state.allusersdata.allusers
   }
}

class Profile extends React.Component
{
    constructor(props){
        super(props)
        this.state = {
            updateProfilemsg : '',
            updatePasswordmsg : '',
            image:null,
            uploadImage:null,
            open:false,
           // userinfo : {userID: '',userName:'',email:'', password:'',userImage:'', avtive:false,role:'',joiningDate:null, oneTimePassword:0}
           userinfo: []
          
        };  
        //console.log(props.user);     
    }

    componentDidUpdate(){
        this.namebox.value = this.state.userinfo.userName
        
    }

   componentDidMount()
    {
       // this.props.data();
        //console.log(this.props.user)
        userService.getUser(this.props.user.token).then(response=>response.json()).then(data=>{
            //console.log(this.props.user.token);
            console.log(data)
            if(data.active)
            {
                //console.log(data.status)
                Store.dispatch({...ACTION_USER_UPDATE_TOKEN,payload:{
                    token : this.props.user.token
                }})
                //console.log(data.token);
                this.setState({userinfo:data})
                console.log(this.state.userinfo)
                
            }else{
                if(data.code===401)
                    alert("Invalid User !")
                if(data.code===403)
                    alert("Session Lost !")  
                Store.dispatch({...ACTION_USER_LOGOUT})                      
            }
            
        });
       
    }
   

    updateProfile =(event)=>
    {
        var ob = {
            userName : this.namebox.value,
            
        }
        //console.log(this.props.user.token)
        userService.updateProfile(ob, this.props.user.token).then(response=>response.json()).then(data=>{
            console.log(data)
            this.componentDidMount();
        this.setState({updateProfilemsg:data.msg})
        this.setState({userinfo:data.data})
        
        });
       // this.componentDidMount()
        event.preventDefault()
    }
    
    updatePassword =(event)=>{
        var ob = {
            password : this.oldpwdbox.value,
            
        }
        var newpassword =this.newpwdbox.value
        console.log(newpassword)
        userService.updatePassword(ob, this.props.user.token,newpassword).then(response=>response.json()).then(data=>{
            console.log(data)
            
        this.setState({updatePasswordmsg:data.msg})
        //this.setState({userinfo:data})
        
        });
        event.preventDefault()
    } 
    
  
    handleClose=()=>{
        this.setState({open: false});
    }
    openDialog=(event)=>{
        this.setState({open: true});
        this.setState({uploadImage: URL.createObjectURL(event.target.files[0])});
        this.setState({image: event.target.files[0]});
    }
    uploadImage=(event)=>{
        event.preventDefault()
       // let image=event.target.files[0];
       const thisContext=this;
        if(this.state.image==undefined || this.state.image==null)
            return;
            
        
        var uploadTask = firebase.storage().ref("profile").child(this.state.image.name).put(this.state.image);
        uploadTask.on(
          "state_changed",
          function (snapshot) {
 
          },
          function (error) {
          },
          function () {
            uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                let payload = {
                     "userID": thisContext.props.user.userID,
                    "userImage" : downloadURL
                }
    
                const requestOptions ={
                    method: "POST",
                    headers: { 'Content-Type': 'application/json' },
                    body : JSON.stringify(payload),
                };
    
                fetch("http://localhost:8080/user/uploadImage",requestOptions)
                .then(data => {
                    //console.log(data)
                   // thisContext.props.refresh();
                    //thisContext.props.update();
                    thisContext.setState({open: false});
                   // thisContext.props.update();
                   thisContext.componentDidMount()
                })
                .catch(error =>{
                    console.log(error)
                })
            })
         }
        );
        

    }
   
   
    render()
    {
        if(this.props.user.loginstatus===false){
            return <Navigate to="/"/>
        }
       
        return <div>
        {/*}  <div className='main-body'>
            <div className="container mt-4 mb-4 p-3 d-flex justify-content-center">
            
               <div className="row">
                  <div className="col-md-12">
                     <div className="titlepage">
                        <h2>User Profile ({this.state.userinfo.userName})</h2>
                     </div>
                  </div>
               </div>
            </div>
    </div>*/}
           
         <div className="container  d-flex justify-content-center">
         <div className="card p-4">
             <div className='row'>
             <div className='col-lg-4 '>
             <div className="container justify-content-center">
                    <h2>User Info</h2> 
                    <br/> 
                    <div className="file-upload">
                    <label for="file-upload" className="file-upload">
                    <img className="profile_img" src={this.state.userinfo.userImage} width="150" height="150"/>
                    <input type="file" id="file-upload" onChange={this.openDialog} />
                    </label>
                    </div>
                    <br/>
                    <h5><b>{this.state.userinfo.userName}</b></h5><br/>
                    <h5>{this.state.userinfo.email}</h5><br/>
                    <h5>{this.state.userinfo.joiningDate}</h5>
                    <hr/>
                    <h5><Link to="/friends">Friends</Link></h5><br/>
                    <Link to="/friendrequest"><h5>Find Friends</h5></Link>
                    </div>
                   
                </div> 
            
            
                <div className='col-lg-4'>
                    <br/><br/><br/>
                    <h2>Update Profile</h2>
                    <br/>
                    <form class="main_form" onSubmit={this.updateProfile}>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <input ref={c=>this.namebox=c} class="form-control" placeholder="Your name" type="text" name="Your Name" required/>
                            </div>
                            <br/>
                            <div className="col-md-6">
                                &nbsp;
                                <b className='text-success'>{this.state.updateProfilemsg}</b>
                            </div>
                            <br/>
                            <div >
                                <button className="btn btn-dark btn-lg btn-block" type='submit' >Update</button>                               
                            </div>
                           
                        </div>
                    </form>
                    <br/>
                    <Dialog aria-labelledby="simple-dialog-title" className="upload__dialogbox" open={this.state.open}>
                <div className="upload__header">
                    <div className="upload__text">Update Profile</div>
                    <div className="upload__close"><span onClick={this.handleClose}>X</span></div>
                </div>   
                
                <img src={this.state.uploadImage} className="upload__preview" />
                <input type="button" value="Upload" onClick={this.uploadImage} className="upload__button" />
            </Dialog>
                 
                   
                        
                </div>
                <div className='col-lg-4'>
                    <br/><br/><br/>
                <h2>Change Password</h2>
                <br/>
                    <form class="main_form" onSubmit={this.updatePassword}>
                        <div className="row">
                            <div className="col-lg-12">
                            <input ref={c=>this.oldpwdbox=c}className="form-control" placeholder="Old Password" type="password" required />
                            </div>
                            <br/><br/>
                            <div className="col-lg-12">
                                <input ref={c=>this.newpwdbox=c}className="form-control" placeholder="New Password" type="password" required />
                            </div>  
                            <br/>                        
                            <div class="col-md-6">
                                &nbsp;
                                <b className='text-success'>{this.state.updatePasswordmsg}</b>
                            </div>
                            <br/>
                            <div class="col-md-6">
                                <button className="btn2 btn-dark btn-lg btn-block" type='submit'>Change Password</button>                               
                            </div>
                        </div>
                    </form>
                </div>
            </div>
          
            </div>
            
            </div>
           
        </div>
    }
}

export default connect(mapStateToProps)(Profile)
//export default Profile