import packageJson from '../../package.json';
class CommentsService{
    savecomments = (data)=>{
        console.log(data)
        return fetch(`${packageJson.server}/user/saveComments`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
               
            },
            body : JSON.stringify(data)
        })
    }
    getcomments=()=>{
        return fetch(`${packageJson.server}/user/getComments`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
               
            },
         //   body : JSON.stringify(data)
        })
    }
  
} 
var obj = new CommentsService()
export default obj;   