import packageJson from '../../package.json';
class UserService{
    registerUser = (data)=>{
        return fetch(`${packageJson.server}/user/register`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
   loginUser = (data)=>{
        return fetch(`${packageJson.server}/user/login`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
    verifyUser = (data)=>{
        return fetch(`${packageJson.server}/user/verify`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        })
    }
    getUser = (token)=>{
        return fetch(`${packageJson.server}/user/getUser`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization" : /*'Bearer '.concat(token)*/token
            },
          
        })
    }
    
   updateProfile = (data, token)=>{
       //console.log(data)
        return fetch(`${packageJson.server}/user/updateProfile`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization" : /*'Bearer '.concat(token)*/token
            },
            body: JSON.stringify(data)
        })
    }
    getImage=(imagePath)=>{
     //   const formdata = new FormData();
       //  formdata.append("imagePath",imagePath);  
        return fetch(`${packageJson.server}/user/getImage`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                //"Authorization" : token,
                "image": imagePath
            },
           // body: 
                //"imagePath": imagePath,
            //    formdata
        })
    }
    uploadImage=(formData,token)=>{
       // const formdata = new FormData();
       // formdata.append("file",imagePath);  
       //console.log(imagePath)
       console.log(formData)
        return fetch(`${packageJson.server}/user/uploadImage`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                //"Content-Type": "multipart/form-data",
                "Authorization" :token,
               //"image":imagePath
            },
            body: formData
        })
    }
    updatePassword = (data, token, newpassword)=>{
        console.log(newpassword)
         return fetch(`${packageJson.server}/user/updatePassword`,{
             method : 'POST',
             headers:{
                 "Content-Type" : "application/json",
                 "Authorization" : token,
                 "newpassword": newpassword
             },
             body:  JSON.stringify(data),
            //newpassword: 'newpassword'
            
             
         })

     }
 

}
var obj = new UserService()
export default obj;