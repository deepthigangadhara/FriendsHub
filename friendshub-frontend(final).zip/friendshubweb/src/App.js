import React from 'react'
import Registration from './RegistrationComponent/Registration';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { Routes ,Link, Route} from 'react-router-dom';
import Login from './LoginComponent/Login';

import NavBar from './Component/NavBar/NavBar'
import Layout from './Component/NavBar/MainPage/Layout'
import EmailVerification from './OTPComponent/EmailVerification';
import Verified from './OTPComponent/Verified';
import Profile from './Profile Component/Profile';
import FriendRequest from './FriendRequestComponent/FriendRequest';
import Friends from './FriendComponent/Friends';
import * as actions from './appredux/actions/AllUserAction'
import Store from './appredux/store'
import AllUserService from './services/AllUserService'
class App extends React.Component{

  componentDidMount()
  {
    this.getData()
  }
  getData=()=>{
    AllUserService.getAllUsers()
    .then(response=>response.json())
    .then(data=>
      {
        console.log(data)
        Store.dispatch({...actions.ACTION_ALL_USERS,payload:{
                    allusers : data
        }})
      })
    }  
  render(){
    return <div>
      <Link to="/verify"></Link>
      <Link to="/verified"></Link>
      <Link to="/home"></Link>
    <Routes>
    <Route path="/friendrequest" element={<FriendRequest />} />
    </Routes>
     
     <div className="App">
     
          <Routes>
          <Route path="/" element={<Login/>} />
            <Route path="/sign-up" element={<Registration/>} />
            <Route path="/verify" element={<EmailVerification />} />
        <Route path="/verified" element={<Verified />} />
        <Route path="/profile" element={<Profile />} />
      <Route path="/home" element={<><NavBar /><Layout /></>} />
     
      <Route path="/friends" element={<Friends />} />
          </Routes>
    
       
    </div>
   
    <br></br>
         <br></br>
    </div>
  }
}
export default App;
