package com.example.friendshub.Model;

public enum Response {

    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE


}
