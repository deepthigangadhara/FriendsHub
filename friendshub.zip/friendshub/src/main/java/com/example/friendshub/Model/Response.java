package com.example.friendshub.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Response {

   /* SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE;*/

    int code;
    String msg;
    Object object;
    
   


}
