package com.example.friendshub.Service;

import java.sql.Timestamp;
//import java.security.Timestamp;
import java.util.Date;

import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
	UserRepository userRepository;
	
	
	public User saveUser(User user) {
		
		Date date=new Date();
		long time=date.getTime();
		Timestamp dateTime=new Timestamp(time);

		user.setActive(true);
		user.setJoiningDate(dateTime);
		
		return userRepository.save(user);
	}
	
}
