package com.example.friendshub.Model;

import java.sql.Timestamp;

//import java.security.Timestamp;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class User {
    @Id
	private String userID;
	
	private String userName;
    private String email;
    private String password;
	private String userImage;
	private boolean active;
	private Timestamp joiningDate;
    
}
