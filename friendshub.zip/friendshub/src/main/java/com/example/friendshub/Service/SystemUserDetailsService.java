package com.example.friendshub.Service;


import com.example.friendshub.Model.SystemUserDetails;
import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;




@Service
public class SystemUserDetailsService implements UserDetailsService 
{
	@Autowired
	UserRepository userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException 
	{
		User user = userRepo.findByEmail(email);
		System.out.println("user : "+user);
		
		return new SystemUserDetails(user);
	}
}
