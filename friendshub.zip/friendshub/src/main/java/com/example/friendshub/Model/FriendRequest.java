package com.example.friendshub.Model;

import java.util.Date;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class FriendRequest {
    @Id
    private String friendRequestID;

    private String userID;
    private String friend_ID;
    private Date requestDate;
    private Boolean status;
}   
