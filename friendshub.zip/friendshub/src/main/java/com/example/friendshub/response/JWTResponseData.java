package com.example.friendshub.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class JWTResponseData {
    
	private boolean status;
	private String token;
	private String msg;
	
}
