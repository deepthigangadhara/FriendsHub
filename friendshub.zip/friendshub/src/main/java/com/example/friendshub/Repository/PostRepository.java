package com.example.friendshub.Repository;

import java.util.ArrayList;
import java.util.UUID;

import com.example.friendshub.Model.Post;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PostRepository extends MongoRepository<Post, String>{
    ArrayList<Post> findAll();
	
	void deleteById(String postID);
}
