package com.example.friendshub.Model;

import java.sql.Timestamp;
import java.util.Date;
//import java.security.Timestamp;
import java.util.UUID;

import org.springframework.data.annotation.Id;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Post {
    @Id
	private String postID;
	
	private String userID;
	
	private String description;
	private String postImgURL;
	
	private int likes;
	private Date dateTime;
	
	
	public Post() {

	}


	public Post(String postID, String userID, String description, String postImgURL,
			int likes, Date dateTime) {
		super();
		this.postID = postID;
		this.userID = userID;
		this.description = description;
		this.postImgURL = postImgURL;
		this.likes = likes;
		this.dateTime = dateTime;
	}


}
