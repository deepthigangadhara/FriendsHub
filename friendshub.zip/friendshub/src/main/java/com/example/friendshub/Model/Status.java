package com.example.friendshub.Model;

import java.sql.Timestamp;
import java.util.Date;
//import java.security.Timestamp;
import java.util.UUID;

import org.springframework.data.annotation.Id;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class Status {

	@Id
	private UUID statusID;
	
	private String userID;
	private String statusImageURL;
	private Date uploadTIme;
	
	public Status() {
		super();
	}

	public Status(UUID statusID, String userID, String statusImageURL, Timestamp uploadTIme) {
		super();
		this.statusID = statusID;
		this.userID = userID;
		this.statusImageURL = statusImageURL;
		this.uploadTIme = uploadTIme;
	}
    
}
