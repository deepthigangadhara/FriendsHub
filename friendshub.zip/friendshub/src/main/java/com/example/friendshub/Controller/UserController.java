package com.example.friendshub.Controller;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import javax.mail.internet.MimeMessage;

import com.example.friendshub.Model.FriendRequest;
import com.example.friendshub.Model.Friends;
import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.FriendRequestRepository;
import com.example.friendshub.Repository.FriendsRepository;
import com.example.friendshub.Repository.UserRepository;
import com.example.friendshub.Security.JwtTokenUtil;
import com.example.friendshub.Service.FriendRequestService;
import com.example.friendshub.Service.FriendsService;
//import com.example.friendshub.Repository.UserRepository;
import com.example.friendshub.Service.UserService;
import com.example.friendshub.response.ImageResponseData;
import com.example.friendshub.response.JWTResponseData;
import com.example.friendshub.response.ResponseData;

import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.apache.tomcat.util.http.fileupload.FileUploadBase;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;


import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;




@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {


	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	PasswordEncoder passwordEncoder;

	
	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public ResponseData registerUser(@RequestBody User user) {
		if (userRepository.existsByEmail(user.getEmail())) {
			return new ResponseData("User Already Exists!", null, false);
		}
		// user.setPassword(passwordEncoder.encode(user.getPassword()));
		// SendVerifyMail(user.getUserName(),user.getEmail(),121);
		User newUser = userService.saveUser(user);
		if (newUser == null)
			return new ResponseData("Not Implemented", null, false);
		else
			user.setPassword(passwordEncoder.encode(user.getPassword()));
		generateOneTimePassword(newUser);
		return new ResponseData("Successfully Registered", newUser, true);
	}

	public void generateOneTimePassword(User user) {
		Random random = new Random();
		int OTP = 100000 + random.nextInt(900000);
		user.setOneTimePassword(OTP);
		user.setActive(false);
		userRepository.save(user);
		sendOTPEmail(user.getUserName(), user.getEmail(), OTP);
	}

	private boolean sendOTPEmail(String userName, String email, int OTP) {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message);

			helper.setFrom("200deepthig@gmail.com", "Friends Hub");
			helper.setTo(email);

			String subject = "Here's your One Time Password (OTP)";
			String content = "<p>Hello " + userName + "</p>"
					+ "<p>For security reason, you're required to use the following "
					+ "One Time Password to login:</p>"
					+ "<p><b>" + OTP + "</b></p>"
					+ "<br>";

			helper.setSubject(subject);
			helper.setText(content, true);
			mailSender.send(message);
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	@PostMapping("/verify")
	public ResponseData verifyUser(@RequestBody User user) {

		if (userService.verify(user.getOneTimePassword())) {
			return new ResponseData("verify_success", null, true);
		} else {
			return new ResponseData("Invalid OTP", null, false);
		}
	}

	@PostMapping("/login")
	public ResponseEntity loginUser(@RequestBody User user) {
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));

			User newUser = userService.getByEmail(user.getEmail());
			final String token = jwtTokenUtil.generateToken(newUser);

			return ResponseEntity.ok(new JWTResponseData(true, token, "Login Successfully",newUser.getUserID(),newUser.getUserName(),newUser.getEmail(),newUser.getUserImage()));

		} catch (DisabledException e) {
			
			return ResponseEntity.ok(new JWTResponseData(false, "", "User Disabled !","", "","",""));
		} catch (BadCredentialsException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "Invalid User !", "","","",""));
		}

	}


	@PostMapping("/updateProfile")
	public ResponseEntity updateProfile(@RequestHeader (name="Authorization") String token,  @RequestBody User user){
		
		String userID=jwtTokenUtil.getUserIdFromToken(token);
		Optional<User> userData = userRepository.findById(userID);
		
		if (userData.isPresent()) {
			User _user = userData.get();
			_user.setUserName(user.getUserName());
			_user.setUserImage(user.getUserImage());
			User newdata=userRepository.save(_user);
			return ResponseEntity.ok(new JWTResponseData(true, token, "updated Successfully",newdata.getUserID(),newdata.getUserName(),newdata.getEmail(),newdata.getUserImage()));
			//return new ResponseData("updated successfully", newdata,true);
		} else {
			return ResponseEntity.ok(new JWTResponseData(false, token, "Invalid User !", "","","",""));
			//return new ResponseData("update failed", "", false);
		}
	
	}
 
	@PostMapping("/uploadImage")
	public ResponseEntity uploadImage(@RequestHeader (name="Authorization") String token,  @RequestPart("file") MultipartFile imageFile){
		
		try{
		System.out.println(imageFile);
		byte bytes[] = imageFile.getBytes();
		String fileName = imageFile.getOriginalFilename();
		System.out.println(fileName);
		String ext = fileName.substring(fileName.lastIndexOf("."));
    fileName =  UUID.randomUUID().toString() + ext;
		System.out.println(fileName);
		String uploadDir="/home/deepthi/Documents/friendshub/src/main/resources/static/uploadfiles";
		File file = new File(uploadDir,fileName);
		System.out.println(file);
			FileOutputStream fos = new FileOutputStream(file);
		
			fos.write(bytes);
			fos.close();
			
		String userID=jwtTokenUtil.getUserIdFromToken(token);
		Optional<User> userData = userRepository.findById(userID);
		
			User _user = userData.get();
			//_user.setUserName(user.getUserName());
			_user.setUserImage(file.getAbsolutePath());
			User newdata=userRepository.save(_user);
			return ResponseEntity.ok(new JWTResponseData(true, token, "updated Successfully",newdata.getUserID(),newdata.getUserName(),newdata.getEmail(),newdata.getUserImage()));
			//return new ResponseData("updated successfully", newdata,true);
		} catch(IOException e) {
			System.out.println(e);
			return ResponseEntity.ok(new JWTResponseData(false, token, "Invalid User !", "","","",""));
			//return new ResponseData("update failed", "", false);
		}
	
	}
	
	@PostMapping("/getImage")
	public ResponseEntity getImage(@RequestHeader(name="image") String imagePath) 
	{
		try {
		File file = new File("/home/deepthi/Downloads/"+imagePath);
			System.out.println(file);
     	FileInputStream fis = new FileInputStream(file);  
		 System.out.println("fis "+fis);          
        int size = fis.available();
        byte arr[] = new byte[size];
        
        fis.read(arr);
        fis.close();
        byte[] encoded = Base64.getEncoder().encode(arr);
		System.out.println(encoded);
        String fileStr = new String(encoded);
        System.out.println(fileStr);
        ImageResponseData res = new ImageResponseData();
        res.setImageBase64(fileStr);
        res.setStatus(true);
		res.setImagePath("/home/deepthi/Downloads/"+imagePath);
        return ResponseEntity.ok(res);
		}catch(Exception ex) {
			System.out.println(ex);
			ImageResponseData res = new ImageResponseData();	        
	        res.setStatus(false);
	        return ResponseEntity.ok(res);
		}
	}

	/*@PostMapping("/uploadImage")
	public ResponseEntity uploadImage(@RequestHeader (name="Authorization") String token,@RequestHeader("image")  MultipartFile imagePath) 
	{
		String uploadDir = "/home/deepthi/Documents/AngularJS/uploadPatientImages";
		String userID=jwtTokenUtil.getUserIdFromToken(token);
		//Optional<User> userData = userRepository.findById(userID);
		try {
			byte bytes[] = imagePath.getBytes();
			String fileName = imagePath.getOriginalFilename();
			String ext = fileName.substring(fileName.lastIndexOf("."));
			
			fileName = UUID.randomUUID().toString()+ext;
			
//			System.out.println(fileName);
//			System.out.println(bytes.length);
			File file = new File(uploadDir,fileName);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(bytes);
			fos.close();
			
			Optional<User> userData = userRepository.findById(userID);
			User _user = userData.get();
			_user.setUserImage(file.getAbsolutePath());
			userRepository.save(_user);
			
			ImageResponseData res = new ImageResponseData();
	        res.setImagePath(file.getAbsolutePath());
	        res.setStatus(true);
	        return ResponseEntity.ok(res);
		} catch (IOException e) {
			System.out.println(e.getMessage());
			ImageResponseData res = new ImageResponseData();	        
	        res.setStatus(false);
	        return ResponseEntity.ok(res);
		}	
	}*/
	

	@PostMapping("/updatePassword")
	public ResponseData updatePassword(@RequestHeader (name="Authorization") String token,  @RequestBody User user, @RequestHeader(name="newpassword") String newpassword){
		
		String userID=jwtTokenUtil.getUserIdFromToken(token);
		Optional<User> userData = userRepository.findById(userID);
		
		if (userData.isPresent()) {
			User _user = userData.get();
			String password= user.getPassword();			
			System.out.println("new password :" +newpassword);
			System.out.println("password "+password);
			String existspassword=_user.getPassword();
			System.out.println("exists: "+existspassword);
			if (passwordEncoder.matches(password, existspassword)){
					_user.setPassword(passwordEncoder.encode(newpassword));
					User newdata=userRepository.save(_user);
			return new ResponseData("updated successfully",newdata ,true);
		}
		}
		return new ResponseData("update failed", "", false);
	}

	@PostMapping("/getAllUsers")
	public ArrayList<User> getAllUser() {
		return userService.retrieveAllUserDetails();
	}

	

	 @PostMapping("/getUser")
	 public User getUser(/*HttpServletRequest request,*/@RequestHeader (name="Authorization") String jwttoken){
		
		 String userID=jwtTokenUtil.getUserIdFromToken(jwttoken);
		 System.out.println(userID);
		  User userdata=userService.getUserData(userID);
		 return userdata;
		  // return ResponseEntity.ok(new JWTResponseData(true, jwttoken, "fetched Successfully",userdata.getUserID(),userdata.getUserName(),userdata.getEmail(),userdata.getUserImage()));
	}
	@Autowired
	private FriendRequestService friendRequestService;
	@Autowired
	private FriendRequestRepository friendRequestRepository;
	@PostMapping("/save")
	public FriendRequest request(@RequestHeader(name="Authorization")String token,@RequestHeader(name="id")String id,@RequestBody FriendRequest request) {
        String userID=jwtTokenUtil.getUserIdFromToken(token);		
        System.out.println("user "+userID);
		System.out.println("friend"+id);	
		request.setUserID(userID);
		request.setFriend_ID(id);
		return friendRequestService.saveRequest(request);
	}

	@PostMapping("/getAllFriendRequests")
	public ArrayList<FriendRequest> getAllRequests() {
		return friendRequestService.retrieveAllUserDetails();
	}

	@PostMapping("/deleteRequest")
	public ArrayList<FriendRequest> delete(@RequestHeader(name="Authorization")String token,@RequestBody ArrayList<FriendRequest> request) {
		System.out.println(request);
		for(FriendRequest f: request){
			friendRequestRepository.deleteById(f.getFriendRequestID());
			System.out.println(f.getFriendRequestID());
		}
		return friendRequestService.retrieveAllUserDetails();
		//return new ResponseData("deleted successfully", all, true);		
	}

	@Autowired
	FriendsService friendsService;
	@Autowired
	private FriendsRepository friendsRepository;
	
	@PostMapping("/saveFriend")
	public Friends accept(@RequestHeader(name="uid")String userid,@RequestHeader(name="fid")String friendid, @RequestBody Friends friends) {
		friends.setUserID(friendid);
		friends.setFriendID(userid);
		return friendsService.saveFriend(friends);
	}

	@PostMapping("/getAllFriends")
	public ArrayList<Friends> getAllFriends() {
		return friendsService.retrieveAllUserDetails();
	}
    @PostMapping("/deleteFriend")
	public ArrayList<Friends> deletefriend(@RequestBody ArrayList<Friends> friend) {
		System.out.println(friend);
		for(Friends f: friend){
			friendsRepository.deleteById(f.getFriendID());
			System.out.println(f.getFriendID());
		}
		return friendsService.retrieveAllUserDetails();
		//return new ResponseData("deleted successfully", all, true);		
	}

}
