package com.example.friendshub.Controller;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;

import javax.mail.internet.MimeMessage;

import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.UserRepository;
import com.example.friendshub.Security.JwtTokenUtil;
//import com.example.friendshub.Repository.UserRepository;
import com.example.friendshub.Service.UserService;
import com.example.friendshub.response.JWTResponseData;
import com.example.friendshub.response.ResponseData;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public ResponseData registerUser(@RequestBody User user) {
		if (userRepository.existsByEmail(user.getEmail())) {
			return new ResponseData("User Already Exists!", null, false);
		}
		// user.setPassword(passwordEncoder.encode(user.getPassword()));
		// SendVerifyMail(user.getUserName(),user.getEmail(),121);
		User newUser = userService.saveUser(user);
		if (newUser == null)
			return new ResponseData("Not Implemented", null, false);
		else
			user.setPassword(passwordEncoder.encode(user.getPassword()));
		generateOneTimePassword(newUser);
		return new ResponseData("Successfully Registered", newUser, true);
	}

	public void generateOneTimePassword(User user) {
		Random random = new Random();
		int OTP = 100000 + random.nextInt(900000);
		user.setOneTimePassword(OTP);
		user.setActive(false);
		userRepository.save(user);
		sendOTPEmail(user.getUserName(), user.getEmail(), OTP);
	}

	private boolean sendOTPEmail(String userName, String email, int OTP) {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message);

			helper.setFrom("200deepthig@gmail.com", "Friends Hub");
			helper.setTo(email);

			String subject = "Here's your One Time Password (OTP)";
			String content = "<p>Hello " + userName + "</p>"
					+ "<p>For security reason, you're required to use the following "
					+ "One Time Password to login:</p>"
					+ "<p><b>" + OTP + "</b></p>"
					+ "<br>";

			helper.setSubject(subject);
			helper.setText(content, true);
			mailSender.send(message);
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	@PostMapping("/verify")
	public ResponseData verifyUser(@RequestBody User user) {

		if (userService.verify(user.getOneTimePassword())) {
			return new ResponseData("verify_success", null, true);
		} else {
			return new ResponseData("Invalid OTP", null, false);
		}
	}

	@PostMapping("/login")
	public ResponseEntity loginUser(@RequestBody User user) {
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));

			User newUser = userService.getByEmail(user.getEmail());
			final String token = jwtTokenUtil.generateToken(newUser);

			return ResponseEntity.ok(new JWTResponseData(true, token, "Login Successfully"));

		} catch (DisabledException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "User Disabled !"));
		} catch (BadCredentialsException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "Invalid User !"));
		}

	}

	@PutMapping("/updateProfile/{id}")
	public ResponseEntity<User> updateProfile(@PathVariable("id") String userID, @RequestBody User user) {
		Optional<User> userData = userRepository.findById(userID);

		if (userData.isPresent()) {
			User _user = userData.get();
			_user.setUserName(user.getUserName());
			_user.setUserImage(user.getUserImage());

			return new ResponseEntity<>(userRepository.save(_user), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/getUser")
	public ArrayList<User> getUser() {
		return userService.retrieveAllUserDetails();
	}

	@GetMapping("/getAllUsers/{userID}")
	public User getUserDetail(@PathVariable("userID") String userID) {
		return userService.getUserData(userID);
	}

}
