import React from 'react'
import "./Friends.css"
import * as actions from '../appredux/actions/FriendAction'
import FriendService from '../services/FriendService'
import Store from '../appredux/store'
import { connect } from 'react-redux'
var mapStateToProps = state => {
    return {
        allusers: state.allusersdata.allusers,
        user: state.user,
        allfriends: state.allfriendsdata.allFriends
    }

}
class Friends extends React.Component{

    componentDidMount() {
        FriendService.getAllFriends().then(response => response.json()).then(data => {
            console.log(data)
            Store.dispatch({...actions.ACTION_ALL_FRIENDS,payload:{
                allFriends : data
    }})
        }
        );
        console.log(this.props.allfriends)
    }
    friends=()=>{
        var arr = [];
        var user = [];
        //this.setState({friendrequest:this.props.friendrequest})
        user = this.props.allfriends.filter((frnd) => frnd.userID === this.props.user.userID)
        arr = this.props.allusers.filter((usr) => user.find(({ friendID }) => usr.userID === friendID))
        console.log(arr, user)
        return arr;
    }
    deleteFriend=(event,friendid)=>{
        console.log(friendid)       
        var arr=this.props.allfriends.filter((fr)=>fr.friendID===friendid&&fr.userID===this.props.user.userID )
        console.log(arr)       
        FriendService.deletefriend(arr).then(response => response.json()).then(data => {
            console.log(data)          
        });
        this.componentDidMount()
        this.friends();
        event.preventDefault();
    }

    render(){
        return <div>
           <div className="container mt-4 mb-4 p-3 d-flex justify-content-center">
               <div className="card1 p-4">
                   <div className='row'>
                   <div className='col-lg-12 '>
                      <h3><b>Friends</b></h3><br/>
                      <table align="center" cellPadding="10" cellSpacing="5">
                          <tbody>
                          {this.friends().map((usr, index) => {
                              return <tr>
                                   <td> <img src={usr.userImage} height="70" width="70"/>
                                     </td>
                                     <td><b>{usr.userName}</b></td>
                                     <td><button className="btn btn-dark btn-lg btn-block" onClick={event=>this.deleteFriend(event,usr.userID)}>Remove</button></td>
                                     
                              </tr>
                             
                          })}

                          </tbody>
                      </table>
                   </div>
                   </div>
               </div>
               </div> 
        </div>
    }
}
export default connect(mapStateToProps)(Friends)