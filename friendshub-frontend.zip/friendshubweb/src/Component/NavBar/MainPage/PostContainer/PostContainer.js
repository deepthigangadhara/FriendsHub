import React, { Component } from 'react';
import Post from "./Post";
import "./PostContainer.css";
import post_img from "../../../../images/post.jpeg";
import * as actions from '../../../../appredux/actions/PostAction'
import Store from '../../../../appredux/store'
import { connect } from 'react-redux'

 
class PostContainer extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            data: []
         }
    }

    getData=()=>{ 
        const thisContext=this;
        const requestOptions ={
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
           // body : JSON.stringify(payload),
        };

        fetch("http://localhost:8080/user/getPost",requestOptions)
        .then(response => response.json())
        .then(json => {
            console.log(json)
            thisContext.setState({data : json});
            
        })
        .catch(error =>{

        })
        
    }

    componentDidMount(){
        this.getData();
    }
    render() { 
        return ( 
            <div>
                {
                    this.state.data.map((item)=>(
                        <Post object={item} />
                    ))
                }
            </div>
         );
    }
}
 
export default PostContainer;