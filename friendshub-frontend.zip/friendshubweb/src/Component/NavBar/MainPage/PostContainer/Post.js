import { Avatar, Paper } from '@material-ui/core';
import React, { Component } from 'react';
import "./PostContainer.css";
import post from "../../../../images/post.jpeg";
import like from "../../../../images/like.png";
import likebutton from "../../../../images/likebutton.png";
import commentbutton from "../../../../images/comment.png";
import sharebutton from "../../../../images/share.png";
import {connect} from 'react-redux'
import LikesService from "../../../../services/LikesService";
import CommentsService from "../../../../services/CommentsService";
var mapStateToProps = state => {
   return {
      user: state.user,
      allusers: state.allusersdata.allusers,
      //allposts: state.allpostsdata.allposts
   }
   
}

class Post extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            commentList:[],
            //data:[]
        }
       
    }
    
    isImageAvailable=(data)=>
    {
        return data==""?false:true;
    }
    likes=(event)=>{
        var ob={
            userID:this.props.object.userID,
            friendID:this.props.user.userID,
            postID:this.props.object.postID
        }
        LikesService.savelikes(ob).then(response => response.json()).then(data => {
            console.log(data) 
            this.componentDidMount(); 
                    
        }); 
           
        event.preventDefault();
        
    }
   
    submitComments =(event) =>{
        if(event.key == "Enter") {
            let comment=event.currentTarget.value;
            if(comment!= null || comment!=undefined) {

                let ob = {
                    userID: this.props.user.userID,
                    postID: this.props.object.postID,
                    userName:this.props.user.userName,
                    userImage:this.props.user.userImage,
                    time: new Date().getTime(),
                    comment: comment
                }
                CommentsService.savecomments(ob).then(response => response.json()).then(data => {
                    console.log(data) 
                    this.componentDidMount()          
                });              
            }
            
        }
       
        event.preventDefault();
    }
   componentDidMount(){
        this.getComments();
       this.props.data();
      
    }

    getComments=()=>{
       
        CommentsService.getcomments().then(response => response.json()).then(data => {
            console.log(data)   
            this.setState({commentList: data});  
            console.log(this.state.commentList)   
            
        }); 
       
    }
    filterComments=()=>{
        var arr=this.state.commentList.filter((comment)=>this.props.postdata.find(({postID})=>comment.postID===postID))
        console.log(arr)
       return arr
    }
    render() { 
        return ( <div>
            
            <Paper className="post_container">
        
                    <div className='post_header'>
                     
                        <div className='post_header_img'>
                           
                            <Avatar src={this.props.object.userImage} className='post_img'/>
                            &nbsp;&nbsp;&nbsp; <b> {this.props.object.userName}</b>
                        </div>
                       {/*} <div className='post_header_text'>
                       &nbsp;&nbsp;&nbsp; <b> {this.props.object.userName}</b>
        </div>*/}

                    </div>
                {/*description */}
                <div className='post_description'>
                &nbsp;&nbsp;&nbsp;&nbsp;{this.props.object.description}
                </div>
                {/*Image */}
                <div className="post__image">
                        {
                            this.isImageAvailable(this.props.object.postImgURL) ? <img className="post-img"src={this.props.object.postImgURL} width="900px" /> : <span></span>
                        }
                    </div>
                {/*like */}
                <div className="post__likeCountContainer">
                        <div className="post__like">
                            <img className="post__img" src={like} />
                            
                        </div>
                        <div className="post__likecount">
                          
                        {this.props.object.likes}
                        </div>
                        <div className="post__commentcount">
                        {this.props.object.comments}
                         &nbsp;   comments
                        </div>
                    </div>
                    {/*like share box*/}
                    <div className="post__likeShare">
                        <div className="post__tab">
                            <div className="post__tabfirst">
                                <img className="post__tabimg" src={likebutton} onClick={event=>this.likes(event)}/>
                            </div>
                            <div className="post__tabtext">
                                Like
                            </div>
                        </div>

                        <div className="post__tab">
                            <div className="post__tabfirst">
                                <img className="post__tabimg" src={commentbutton} />
                            </div>
                            <div className="post__tabtext">
                                Comment
                            </div>
                        </div>

                        <div className="post__tab">
                            <div className="post__tabfirst">
                                <img className="post__tabimg" src={sharebutton} />
                            </div>
                            <div className="post__tabtext">
                                Share
                            </div>
                        </div>
                    </div>

                         {/* comment box */}
                       <div>
                       {
                  this.filterComments().map((item,index)=>(
                      index < 4 ?
                        <div className="post_comment">&nbsp;<img src={item.userImage} width="40" height="40"/>&nbsp;&nbsp;<b>{item.userName}</b> &nbsp;&nbsp;{item.comment}</div> :<span></span>
                  ))
              }
                       <div className="upload__top">
                    <div>
                        <Avatar src={this.props.user.userImage} className="upload_img"/>
                    </div>
                    <div>
                        <input className="upload__box" placeholder="Add a comment..." text="text"  onKeyUp={event=>this.submitComments(event)}/>
                    </div>
                </div>
                       </div>

            </Paper>
          
       
        </div>
             );
    }
}
 
export default connect(mapStateToProps)(Post);