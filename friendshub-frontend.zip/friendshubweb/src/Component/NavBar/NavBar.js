import React, { Component } from 'react';
import "./NavBar.css";
import Grid from '@material-ui/core/Grid'
import fblogo from "../../images/logo.png";
import home from "../../images/home.svg";
import page from "../../images/pages.svg";
import watch from "../../images/watch.svg";
import market from "../../images/market.svg";
import group from "../../images/groups.svg";
import Avatar from '@material-ui/core/Avatar';
import { Link} from 'react-router-dom';
import {connect} from 'react-redux'
import Store from '../../appredux/store'
import {ACTION_USER_LOGOUT} from '../../appredux/actions/UserAction'


var mapStateToProps = state => {
   return {
      user: state.user,
   }
   
}


class NavBar extends Component {
    constructor(props) {
        super(props);
        this.state = {
           
        }
        //console.log(props.user);
       
    }
    
    render() {
        return (
            <div>
                <Grid container className="navbar_main">
                    <Grid item xs={4}><div className='navbar_leftbar'>
                    <div className='navbar_logo'><h5><b>FriendsHub</b></h5></div>
                       &nbsp;&nbsp;&nbsp;&nbsp;
                        <input className='navbar_search' type="text" placeholder='Search FriendsHub'/>
                    </div></Grid>

                    <Grid item xs={5}> <div className="navbar_container">
                        <div className="navbar_tabs active ">
                       <Link to="/home"> <img src={home} height="35px" width="35px" className="img"/></Link>
                        </div>
                        <div className="navbar_tabs">
                        <img src={page} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={watch} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={market} height="35px" width="35px" className="img"/>
                        </div>
                        <div className="navbar_tabs">
                        <img src={group} height="35px" width="35px" className="img"/>
                        </div>

                    </div>
                    </Grid>

                    <Grid item xs={2}>
                        <div className="navbar_right">
                            <div className='navbar_righttab'>
                                <Link to="/profile">
                                <Avatar className="navbar_rightimg" src={this.props.user.userImage} />
                                </Link>
                               <div className='navbar_profilename'>{this.props.user.userName}</div>
                                </div>
                        </div>
                    </Grid>
                </Grid>
            </div>

        );
    }
}

//export default NavBar;

export default connect(mapStateToProps)(NavBar)