import * as actionType from './ActionTypes'
export const ACTION_ALL_USERS={
    type: actionType.ALL_USERS,
    payload:{
        allusers : undefined
    }
}