import * as actionType from './ActionTypes'
export const ACTION_ALL_FRIENDS = {
    type : actionType.ALL_FRIENDS ,
    payload:{
       
        allFriends:undefined

    }
}