import * as actionType from '../actions/ActionTypes'

export default function AllPostReducer(state=[],action)
{
    switch(action.type){
        case actionType.ALL_POSTS: return {
            ...state,allposts:action.payload.allposts
        }
        
        default: return state                                
    }
}