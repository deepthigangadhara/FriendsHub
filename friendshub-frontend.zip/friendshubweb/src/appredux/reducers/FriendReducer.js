import * as actionType from '../actions/ActionTypes'

export default function FriendReducer(state=[],action){
    switch(action.type)
    {
        case actionType.ALL_FRIENDS: return {
            ...state,allFriends:action.payload.allFriends
        }
        default: return state      
    }
}