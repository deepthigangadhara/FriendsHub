import packageJson from '../../package.json';
class FriendService{
    accept = (userid, friendid, data)=>{
        console.log(userid, friendid)
        return fetch(`${packageJson.server}/user/saveFriend`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "uid":userid,
                "fid":friendid
            },
            body : JSON.stringify(data)
        })
    }
    getAllFriends = ()=>{
        return fetch(`${packageJson.server}/user/getAllFriends`,{
            method : 'POST',
            
        })
    }
    deletefriend = (arr)=>{
        console.log(arr)
        return fetch(`${packageJson.server}/user/deleteFriend`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                //"Authorization":token,
                //"id":requestid
            },
            body : JSON.stringify(arr)
        })
    }
} 
var obj = new FriendService()
export default obj;   