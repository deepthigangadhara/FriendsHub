import packageJson from '../../package.json';
class LikesService{
    savelikes = (data)=>{
        console.log(data)
        return fetch(`${packageJson.server}/user/saveLikes`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
               
            },
            body : JSON.stringify(data)
        })
    }
  
} 
var obj = new LikesService()
export default obj;   