import packageJson from '../../package.json';
class LikesService{
    savelikes = (data)=>{
        console.log(data)
        return fetch(`${packageJson.server}/user/saveLikes`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
               
            },
            body : JSON.stringify(data)
        })
    }
  /*  getAllFriends = ()=>{
        return fetch(`${packageJson.server}/user/getAllFriends`,{
            method : 'POST',
            
        })
    }*/
   
} 
var obj = new LikesService()
export default obj;   