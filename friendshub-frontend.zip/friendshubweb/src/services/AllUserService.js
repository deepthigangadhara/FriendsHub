import packageJson from '../../package.json';
class AllUserService
{
    getAllUsers = ()=>{
        return fetch(`${packageJson.server}/user/getAllUsers`,{
            method : 'POST',
            /*headers:{
                "Content-Type" : "application/json",
                "Authorization" : token
            }*/
        })
    }
    
}
var obj = new AllUserService()
export default obj;