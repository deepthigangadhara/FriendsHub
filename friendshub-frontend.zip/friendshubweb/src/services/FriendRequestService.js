import packageJson from '../../package.json';
class FriendRequestService{
    request = (userid, token, data)=>{
        console.log(userid, token)
        return fetch(`${packageJson.server}/user/save`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization":token,
                "id":userid
            },
            body : JSON.stringify(data)
        })
    }
    getAllRequests = ()=>{
        return fetch(`${packageJson.server}/user/getAllFriendRequests`,{
            method : 'POST',
            /*headers:{
                "Content-Type" : "application/json",
                "Authorization" : token
            }*/
        })
    }
    delete = (arr, token)=>{
        console.log(arr)
        return fetch(`${packageJson.server}/user/deleteRequest`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json",
                "Authorization":token,
                //"id":requestid
            },
            body : JSON.stringify(arr)
        })
    }
    
}
var obj = new FriendRequestService()
export default obj;