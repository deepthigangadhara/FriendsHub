import firebase from "firebase";



var firebaseConfig = {
    apiKey: "AIzaSyD2JMOgDVeWR84OnEVxZkOxjst3GfGAViI",

    authDomain: "friendshub-aa890.firebaseapp.com",
  
    projectId: "friendshub-aa890",
  
    storageBucket: "friendshub-aa890.appspot.com",
  
    messagingSenderId: "278424457150",
  
    appId: "1:278424457150:web:94619d0e4af860a2bdf3ef"
 
  };

// var firebaseConfig = {
//     apiKey: "AIzaSyDvN3gEv8Fte7hoAFNq98oad1h9F30FMPg",
//     authDomain: "facebook-clone-e8f34.firebaseapp.com",
//     projectId: "facebook-clone-e8f34",
//     storageBucket: "facebook-clone-e8f34.appspot.com",
//     messagingSenderId: "784890696432",
//     appId: "1:784890696432:web:5e7fc1581853f5a1486835"
// };
firebase.initializeApp(firebaseConfig);

export  {firebase};