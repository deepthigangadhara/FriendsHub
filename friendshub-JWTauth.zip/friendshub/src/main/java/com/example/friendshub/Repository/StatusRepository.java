package com.example.friendshub.Repository;

import java.util.ArrayList;

import com.example.friendshub.Model.Status;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface StatusRepository extends MongoRepository<Status, String>{

    ArrayList<Status> findAll();
}
