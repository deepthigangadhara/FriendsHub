package com.example.friendshub.Service;

import java.util.ArrayList;
//import java.sql.Timestamp;
//import java.security.Timestamp;
import java.util.Date;
//import java.util.List;

import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
	UserRepository userRepository;
	
	
	public User saveUser(User user) 
	{
		try {
			user.setRoles("ROLE_USER");
			user.setActive(true);
			Date date=new Date();
			user.setJoiningDate(date);
			userRepository.insert(user);		
			return user;
		}catch(Exception ex) {
			return null;
		}
	}
	public User getById(String userid) 
	{
		return userRepository.findById(userid).get();	
	}
	public User getByEmail(String email) 
	{
		return userRepository.findByEmail(email);		
	}



	public ArrayList<User> retrieveAllUserDetails(){
		return userRepository.findAll();
	}
	
	public User getUserData(String userID) {
		return userRepository.findAllByuserID(userID);
	}


}
