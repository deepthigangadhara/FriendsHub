package com.example.friendshub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendshubApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendshubApplication.class, args);
	}

}
