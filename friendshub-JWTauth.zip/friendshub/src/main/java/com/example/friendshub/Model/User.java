package com.example.friendshub.Model;


import java.util.Date;

import java.util.Objects;



import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class User {
    @Id
	private String userID;

	private String userName;
    private String email;
    private String password;
	private String userImage;
	private Boolean active;
    private String roles;
	//private Timestamp joiningDate;
    private Date joiningDate;
	


   /* @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return Objects.equals(email, user.email) &&
                Objects.equals(password, user.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userID, email, password);
    }*/
    
}
