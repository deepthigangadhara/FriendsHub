package com.example.friendshub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendshubApplicationTests {

	@Test
	void contextLoads() {
	}

}
