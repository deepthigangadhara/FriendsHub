package com.example.friendshub.Repository;

import java.util.ArrayList;

import com.example.friendshub.Model.Likes;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface LikesRepository extends MongoRepository<Likes,String>{
    ArrayList<Likes> findAll();
}
