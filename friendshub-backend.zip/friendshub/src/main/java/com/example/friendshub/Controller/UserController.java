package com.example.friendshub.Controller;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;

import javax.mail.internet.MimeMessage;

import com.example.friendshub.Model.Comments;
import com.example.friendshub.Model.FriendRequest;
import com.example.friendshub.Model.Friends;
import com.example.friendshub.Model.Likes;
import com.example.friendshub.Model.Post;
import com.example.friendshub.Model.Status;
import com.example.friendshub.Model.User;
import com.example.friendshub.Repository.FriendRequestRepository;
import com.example.friendshub.Repository.FriendsRepository;
import com.example.friendshub.Repository.PostRepository;
import com.example.friendshub.Repository.UserRepository;
import com.example.friendshub.Security.JwtTokenUtil;
import com.example.friendshub.Service.CommentsService;
import com.example.friendshub.Service.FriendRequestService;
import com.example.friendshub.Service.FriendsService;
import com.example.friendshub.Service.LikesService;
import com.example.friendshub.Service.PostService;
import com.example.friendshub.Service.StatusService;
import com.example.friendshub.Service.UserService;
import com.example.friendshub.response.JWTResponseData;
import com.example.friendshub.response.ResponseData;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/register")
	public ResponseData registerUser(@RequestBody User user) {
		if (userRepository.existsByEmail(user.getEmail())) {
			return new ResponseData("User Already Exists!", null, false);
		}
		User newUser = userService.saveUser(user);
		if (newUser == null)
			return new ResponseData("Not Implemented", null, false);
		else
			user.setPassword(passwordEncoder.encode(user.getPassword()));
		generateOneTimePassword(newUser);
		return new ResponseData("Successfully Registered", newUser, true);
	}

	public void generateOneTimePassword(User user) {
		Random random = new Random();
		int OTP = 100000 + random.nextInt(900000);
		user.setOneTimePassword(OTP);
		user.setActive(false);
		userRepository.save(user);
		sendOTPEmail(user.getUserName(), user.getEmail(), OTP);
	}

	private boolean sendOTPEmail(String userName, String email, int OTP) {
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message);

			helper.setFrom("200deepthig@gmail.com", "Friends Hub");
			helper.setTo(email);

			String subject = "Here's your One Time Password (OTP)";
			String content = "<p>Hello " + userName + "</p>"
					+ "<p>For security reason, you're required to use the following "
					+ "One Time Password to login:</p>"
					+ "<p><b>" + OTP + "</b></p>"
					+ "<br>";

			helper.setSubject(subject);
			helper.setText(content, true);
			mailSender.send(message);
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	@PostMapping("/verify")
	public ResponseData verifyUser(@RequestBody User user) {

		if (userService.verify(user.getOneTimePassword())) {
			return new ResponseData("verify_success", null, true);
		} else {
			return new ResponseData("Invalid OTP", null, false);
		}
	}

	@PostMapping("/login")
	public ResponseEntity loginUser(@RequestBody User user) {
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
			User newUser = userService.getByEmail(user.getEmail());
			final String token = jwtTokenUtil.generateToken(newUser);
			return ResponseEntity.ok(new JWTResponseData(true, token, "Login Successfully", newUser.getUserID(),
					newUser.getUserName(), newUser.getEmail(), newUser.getUserImage()));
		} catch (DisabledException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "User Disabled !", "", "", "", ""));
		} catch (BadCredentialsException e) {
			return ResponseEntity.ok(new JWTResponseData(false, "", "Invalid User !", "", "", "", ""));
		}
	}

	@PostMapping("/updateProfile")
	public ResponseData updateProfile(@RequestHeader(name = "Authorization") String token, @RequestBody User user) {
		String userID = jwtTokenUtil.getUserIdFromToken(token);
		Optional<User> userData = userRepository.findById(userID);
		if (userData.isPresent()) {
			User _user = userData.get();
			_user.setUserName(user.getUserName());
			User newdata = userRepository.save(_user);
			return new ResponseData("updated successfully", newdata, true);
		} else {
			return new ResponseData("update failed", "", false);
		}
	}

	@PostMapping("/uploadImage")
	public ResponseData uploadImage(@RequestBody User user) {
		Optional<User> userData = userRepository.findById(user.getUserID());
		if (userData.isPresent()) {
			User _user = userData.get();
			_user.setUserImage(user.getUserImage());
			User newdata = userRepository.save(_user);
			return new ResponseData("updated successfully", newdata, true);
		} else {
			return new ResponseData("update failed", "", false);
		}
	}

	@PostMapping("/updatePassword")
	public ResponseData updatePassword(@RequestHeader(name = "Authorization") String token, @RequestBody User user,
			@RequestHeader(name = "newpassword") String newpassword) {
		String userID = jwtTokenUtil.getUserIdFromToken(token);
		Optional<User> userData = userRepository.findById(userID);
		if (userData.isPresent()) {
			User _user = userData.get();
			String password = user.getPassword();
			System.out.println("new password :" + newpassword);
			System.out.println("password " + password);
			String existspassword = _user.getPassword();
			System.out.println("exists: " + existspassword);
			if (passwordEncoder.matches(password, existspassword)) {
				_user.setPassword(passwordEncoder.encode(newpassword));
				User newdata = userRepository.save(_user);
				return new ResponseData("updated successfully", newdata, true);
			}
		}
		return new ResponseData("update failed", "", false);
	}

	@PostMapping("/getAllUsers")
	public ArrayList<User> getAllUser() {
		return userService.retrieveAllUserDetails();
	}

	@PostMapping("/getUser")
	public User getUser(@RequestHeader(name = "Authorization") String jwttoken) {
		String userID = jwtTokenUtil.getUserIdFromToken(jwttoken);
		System.out.println(userID);
		User userdata = userService.getUserData(userID);
		return userdata;
	}

	@Autowired
	private FriendRequestService friendRequestService;
	@Autowired
	private FriendRequestRepository friendRequestRepository;

	@PostMapping("/save")
	public FriendRequest request(@RequestHeader(name = "Authorization") String token,
			@RequestHeader(name = "id") String id, @RequestBody FriendRequest request) {
		String userID = jwtTokenUtil.getUserIdFromToken(token);
		System.out.println("user " + userID);
		System.out.println("friend" + id);
		request.setUserID(userID);
		request.setFriend_ID(id);
		return friendRequestService.saveRequest(request);
	}

	@PostMapping("/getAllFriendRequests")
	public ArrayList<FriendRequest> getAllRequests() {
		return friendRequestService.retrieveAllUserDetails();
	}

	@PostMapping("/deleteRequest")
	public ArrayList<FriendRequest> delete(@RequestHeader(name = "Authorization") String token,
			@RequestBody ArrayList<FriendRequest> request) {
		System.out.println(request);
		for (FriendRequest f : request) {
			friendRequestRepository.deleteById(f.getFriendRequestID());
			System.out.println(f.getFriendRequestID());
		}
		return friendRequestService.retrieveAllUserDetails();
	}

	@Autowired
	FriendsService friendsService;
	@Autowired
	private FriendsRepository friendsRepository;

	@PostMapping("/saveFriend")
	public Friends accept(@RequestHeader(name = "uid") String userid, @RequestHeader(name = "fid") String friendid,
			@RequestBody Friends friends) {
		friends.setUserID(friendid);
		friends.setFriendID(userid);
		return friendsService.saveFriend(friends);
	}

	@PostMapping("/getAllFriends")
	public ArrayList<Friends> getAllFriends() {
		return friendsService.retrieveAllUserDetails();
	}

	@PostMapping("/deleteFriend")
	public ArrayList<Friends> deletefriend(@RequestBody ArrayList<Friends> friend) {
		System.out.println(friend);
		for (Friends f : friend) {
			friendsRepository.deleteById(f.getFriendID());
			System.out.println(f.getFriendID());
		}
		return friendsService.retrieveAllUserDetails();
	}

	@Autowired
	StatusService statusService;

	@PostMapping("/saveStatus")
	public Status saveStatus(@RequestBody Status status) {
		return statusService.saveStatus(status);
	}

	@PostMapping("/getAllStatus")
	public ArrayList<Status> getAllStatus() {
		return statusService.getAllStatus();
	}

	@Autowired
	PostService postService;

	@PostMapping("/savePost")
	public ArrayList<Post> submitPost(@RequestBody Post body) {
		ArrayList<Post> result = postService.submitPostToDB(body);
		return result;
	}

	@PostMapping("/getPost")
	public ArrayList<Post> retrieveAllPost() {
		ArrayList<Post> result = postService.retrivePostFromDB();
		result.sort((e1, e2) -> e2.getDateTime().compareTo(e1.getDateTime()));
		return result;
	}

	@PostMapping("/getAllPosts")
	public ArrayList<Post> retrieveAllPostWithoutSort() {
		ArrayList<Post> result = postService.retrivePostFromDB();
		return result;
	}


	@DeleteMapping("/delete/{postId}")
	public ArrayList<Post> deleteParticularPost(@PathVariable("postId") String postID) {
		ArrayList<Post> result = postService.deletePostFromDB(postID);
		return result;
	}

	@Autowired
	LikesService likesService;

	@Autowired
	private PostRepository postRepository;

	@PostMapping("/saveLikes")
	public Likes savelikes(@RequestBody Likes likes) {
		likes.setUserID(likes.getUserID());
		likes.setFriendID(likes.getFriendID());
		likes.setPostID(likes.getPostID());
		Optional<Post> _post = postRepository.findById(likes.getPostID());
		Post post = _post.get();
		System.out.println(post);
		int like = post.getLikes();
		like = like + 1;
		post.setLikes(like);
		System.out.println(post.getLikes());
		postService.submitPostToDB(post);
		return likesService.saveLikes(likes);
	}

	@Autowired
	CommentsService commentsService;

	@PostMapping("/saveComments")
	public Comments savecomments(@RequestBody Comments comments) {
		comments.setUserID(comments.getUserID());
		comments.setPostID(comments.getPostID());
		comments.setUserName(comments.getUserName());
		comments.setUserImage(comments.getUserImage());
		comments.setComment(comments.getComment());
		comments.setTime(comments.getTime());
		Optional<Post> _post = postRepository.findById(comments.getPostID());
		Post post = _post.get();
		System.out.println(post);
		int comment = post.getComments();
		comment = comment + 1;
		post.setComments(comment);
		System.out.println(post.getComments());
		postService.submitPostToDB(post);
		return commentsService.saveComments(comments);
	}

	@PostMapping("/getComments")
	public ArrayList<Comments> getComments() {
		ArrayList<Comments> result = commentsService.retrieveAllComments();
		result.sort((e1, e2) -> e2.getTime().compareTo(e1.getTime()));
		return result;
	}

}
