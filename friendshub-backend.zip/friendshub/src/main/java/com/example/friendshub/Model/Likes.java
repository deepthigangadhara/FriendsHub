package com.example.friendshub.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Likes {
    private String userID;
    private String friendID;
    private String postID;
    
}
