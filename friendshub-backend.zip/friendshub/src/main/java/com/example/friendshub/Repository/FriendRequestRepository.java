package com.example.friendshub.Repository;

import java.util.ArrayList;

import com.example.friendshub.Model.FriendRequest;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface FriendRequestRepository extends MongoRepository<FriendRequest, String>{
    ArrayList<FriendRequest> findAll();
   
}
