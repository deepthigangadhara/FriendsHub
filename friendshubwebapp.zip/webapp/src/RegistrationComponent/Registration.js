import React from 'react'
import userService from '../services/UserService'
class Registration extends React.Component {
    constructor(){
        super()
        this.state = {
            
        }
    }
        register = (event)=>{
            var ob = {
                userName : this.namebox.value,
                email : this.emailbox.value,
                password : this.pwdbox.value,
               
            }
            console.log(ob)
         
          userService.registerUser(ob)
           
            event.preventDefault()
        }
    
    render(){
        return <div>
            <h2>User Registeration</h2>
                    <form class="main_form" onSubmit={this.register}>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                <input ref={c=>this.namebox=c} class="form-control" placeholder="Your name" type="text" name="Your Name" required/>
                            </div>
                          
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                <input ref={c=>this.emailbox=c}class="form-control" placeholder="Email" type="text" name="Email" required />
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                <input ref={c=>this.pwdbox=c}class="form-control" placeholder="Password" type="password" required/>
                            </div>
                           
                          
                            <div class="col-md-6">
                                <button type='submit' class="send">Register</button>                               
                            </div>
                        </div>
                    </form>
        </div>
    }
}
export default Registration