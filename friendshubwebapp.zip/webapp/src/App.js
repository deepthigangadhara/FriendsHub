import React from 'react'
import Registration from './RegistrationComponent/Registration';
class App extends React.Component{
  render(){
    return <div>
      <Registration/>
    </div>
  }
}
export default App;
