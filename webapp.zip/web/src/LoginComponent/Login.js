import React from 'react'
class Login extends React.Component {
    constructor() {
        super()
    }
    render() {
        return <div>
             <br></br>
         <br></br>
            <form onSubmit={this.login}>

                <h3>Log in</h3>

                <div className="form-group">
                    <label>Email</label>
                    <input ref={c=>this.loginemailbox=c} type="email" className="form-control" placeholder="Enter email" required/>
                </div>
                <br></br>

                <div className="form-group">
                    <label>Password</label>
                    <input ref={c=>this.loginpwdbox=c} type="password" className="form-control" placeholder="Enter password" required/>
                </div>
                <br></br>

                <div className="form-group">
                    <div className="custom-control custom-checkbox">
                        <input type="checkbox" className="custom-control-input" id="customCheck1" />
                        <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                    </div>
                </div>
                <br></br>

                <button type="submit" className="btn btn-dark btn-lg btn-block">Sign in</button>
                <p className="forgot-password text-right">
                    Forgot <a href="#">password?</a>
                </p>
            </form>
        </div>
    }
}
export default Login